﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Vespignani.Guido
{
    public class Manzana : Fruta,ISerializable
    {
        public string distribuidora;
        private string ruta;

        public string Tipo { get { return "Manzana"; } }

        public override bool TieneCarozo
        {
            get { return true; }
        }

        public Manzana()
        { }

        public Manzana(float peso, ConsoleColor color, string dist)
            : base(peso, color)
        {
            this.distribuidora = dist;
        }

        protected override string FrutaToString()
        {
            StringBuilder s = new StringBuilder();
            s.AppendLine(base.FrutaToString());
            s.AppendLine("Distribuidora: " + this.distribuidora);
            return s.ToString();
        }

        public override string ToString()
        {
            return base.FrutaToString();
        }

        public string RutaArchivo
        {
            get
            {
                return this.ruta;
            }
            set
            {
                
                this.ruta = value;
            }
        }

        public bool Deserealizar()
        {
            try
            {
                Manzana aux;
                XmlSerializer xmlser = new XmlSerializer(typeof(Manzana));
                XmlTextReader xmlrea = new XmlTextReader(this.RutaArchivo);
                aux = (Manzana)xmlser.Deserialize(xmlrea);
                xmlrea.Close();
                this._peso = aux._peso;
                this._color = aux._color;
                this.distribuidora = aux.distribuidora;
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public bool SerialiarXML()
        {
            try
            {
                XmlSerializer xmlser = new XmlSerializer(typeof(Manzana));
                XmlTextWriter xmlwri = new XmlTextWriter(this.RutaArchivo, Encoding.UTF8);
                xmlser.Serialize(xmlwri, this);
                xmlwri.Close();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
    }
}
