﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vespignani.Guido
{
    public class Platano : Fruta
    {
        public string paisOrigen;

        public string Tipo
        {
            get { return "Plátano"; }
        }
        public override bool TieneCarozo
        {
            get { return false; }
        }
        public Platano(float peso, ConsoleColor color, string origen)
            : base(peso, color)
        {
            this.paisOrigen = origen;
        }
        protected override string FrutaToString()
        {
            StringBuilder s = new StringBuilder();
            s.AppendLine(base.FrutaToString());
            s.AppendLine("Pais Origen: " + this.paisOrigen);
            return s.ToString();
        }
        public override string ToString()
        {
            return this.FrutaToString();
        }

    }
}
