﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Vespignani.Guido
{
    public static class Ticketeadora
    {
        public static bool ImprimirTicket(this Cajon<Platano> c , string path)
        {
            try
            {
                StringBuilder s = new StringBuilder();
                s.AppendLine("Fecha: " + DateTime.Now);
                s.AppendLine("Precio Total:" + c.PrecioTotal);
                StreamWriter sw = new StreamWriter(path);
                sw.WriteLine(s.ToString());
                sw.Close();
                return true;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
    }
}
