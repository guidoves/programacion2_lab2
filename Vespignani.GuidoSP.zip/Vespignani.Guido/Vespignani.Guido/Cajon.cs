﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Vespignani.Guido
{
    public class Cajon<T> : ISerializable
    {
        private int _capacidad;
        private List<T> _frutas;
        private float _precioUnitario;
        private string ruta;

        public List<T> Frutas { get { return _frutas; } }
        public float PrecioTotal 
        {
            get {
                float precio = this._frutas.Count * this._precioUnitario;
                return precio;
            } 
        }

        public Cajon()
        {
            this._frutas = new List<T>();
        }
        public Cajon(int capacidad):this()
        {
            this._capacidad = capacidad;
        }
        public Cajon(int capacidad, float precio):this(capacidad)
        {
            this._precioUnitario = precio;
        }

        public override string ToString()
        {
            StringBuilder s = new StringBuilder();
            s.AppendLine("Capacidad: " + this._capacidad);
            s.AppendLine("Cantidad total de frutas: " + this._frutas.Count);
            s.AppendLine("Precio Total: " + this.PrecioTotal);
            s.AppendLine("Listado de frutas:");
            foreach (T item in this._frutas)
            {
                s.AppendLine(item.ToString());
            }
            return s.ToString();
        }

        public static Cajon<T> operator +(Cajon<T> c, T f)
        {
            if (c._frutas.Count < c._capacidad)
            {
                c._frutas.Add(f);
                return c;
            }
            else
            {
                throw new CajonLlenoException("El cajon no tiene lugar disponible.");
            }
        }

        public string RutaArchivo
        {
            get
            {
                return this.ruta;
            }
            set
            {
                this.ruta = value;
            }
        }

        public bool Deserealizar()
        {
            try
            {
                Cajon<T> aux;
                XmlSerializer xmlser = new XmlSerializer(typeof(Cajon<T>));
                XmlTextReader xmlrea = new XmlTextReader(this.RutaArchivo);
                aux = (Cajon<T>)xmlser.Deserialize(xmlrea);
                xmlrea.Close();
                this._capacidad = aux._capacidad;
                this._frutas = aux._frutas;
                this._precioUnitario = aux._precioUnitario;
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public bool SerialiarXML()
        {
            try
            {
                XmlSerializer xmlser = new XmlSerializer(typeof(Cajon<T>));
                XmlTextWriter xmlwri = new XmlTextWriter(this.RutaArchivo, Encoding.UTF8);
                xmlser.Serialize(xmlwri, this);
                xmlwri.Close();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
    }
}
