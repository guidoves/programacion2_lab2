﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vespignani.Guido
{
    public interface ISerializable
    {
         string RutaArchivo { get; set; }
         bool Deserealizar();
        bool SerialiarXML();
    }

}
