﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vespignani.Guido;
namespace Inicio
{
    class Program
    {
        private static bool Serializar(ISerializable obj)
        {
            return obj.SerialiarXML();
        }
        private static bool Deserializar(ISerializable obj)
        {
            return obj.Deserealizar();
        }

        static void Main(string[] args)
        {
            try
            {
                Platano p1 = new Platano(2.2f, ConsoleColor.DarkBlue, "ecuador");
                Platano p2 = new Platano(1.4f, ConsoleColor.DarkGray, "argentina");
                Manzana m1 = new Manzana(1.2f, ConsoleColor.Red, "s");
                Manzana m2 = new Manzana(0.8f, ConsoleColor.White, "d");
                Manzana m3 = new Manzana(0.6f, ConsoleColor.Yellow, "a");
                Manzana m4 = new Manzana(0.7f, ConsoleColor.Green, "s");
                Cajon<Manzana> cajonManzana = new Cajon<Manzana>(3, 5.3f);
                Cajon<Manzana> cajonManzana2 = new Cajon<Manzana>(8, 5.2f);
                Cajon<Platano> cajonPlatano = new Cajon<Platano>(3, 8.3f);
                cajonPlatano += p1;
                cajonManzana += m1;
                Console.WriteLine(cajonManzana.ToString());
                Console.ReadLine();
                cajonManzana += m2;
                Console.WriteLine(cajonManzana.ToString());
                Console.ReadLine();
                cajonManzana += m3;
                Console.WriteLine(cajonManzana.ToString());
                Console.ReadLine();
                
                
                Console.WriteLine(cajonManzana2.ToString());
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadLine();
            }
        }
        
    }
}
