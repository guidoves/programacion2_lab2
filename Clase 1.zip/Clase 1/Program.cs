﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vespignani.guido.ejer02
{
    class Program
    {
        static void Main(string[] args)
        {
            double num,cuadrado,cubo;
            System.Console.WriteLine("Ingrese un numero mayor que 0: ");
            num = double.Parse(System.Console.ReadLine());
            while (num < 1)
            {
                System.Console.WriteLine("ERROR. Reingresar numero");
                num = float.Parse(System.Console.ReadLine());
            }
            //cuadrado = System.Math.Pow(num,2);
            //cubo = System.Math.Pow(num,3);
            System.Console.WriteLine("Numero al cuadrado: {0:R}", System.Math.Pow(num,2));
            System.Console.WriteLine("Numero al cubo: {0:R}", System.Math.Pow(num,3));
            System.Console.ReadLine();
        }
    }
}
